# Soil Health Nutrient Analysis

This project scrapes, consolidates, and analyzes soil health data (Macro and Micro nutrients) from [Soil Health Portal](https://soilhealth.dac.gov.in/piechart).

## 📁 Project Structure
- `get_raw_data.py`: Scrapes nutrient data across states, districts, blocks.
- `consolidate_data.py`: Merges and standardizes all data into a single file.
- `eda_analysis.ipynb`: Exploratory data analysis and insights.
- `data/raw/`: Contains year-wise, state-wise extracted CSVs.
- `data/processed/`: Final consolidated data.

## 🔧 Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run scraping:
   ```bash
   python get_raw_data.py
   ```
3. Consolidate:
   ```bash
   python consolidate_data.py
   ```
4. Explore in Jupyter:
   ```bash
   jupyter notebook eda_analysis.ipynb
   ```

## 🧠 Insights
- Nutrient deficiency heatmaps
- Trends by state/year
- Distribution plots and summaries
