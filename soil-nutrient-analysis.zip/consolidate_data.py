
import os
import pandas as pd

def consolidate_data(raw_path="data/raw", output_path="data/processed/soil_health_consolidated.csv"):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    combined = []
    for year in os.listdir(raw_path):
        year_path = os.path.join(raw_path, year)
        for state in os.listdir(year_path):
            state_path = os.path.join(year_path, state)
            for district in os.listdir(state_path):
                district_path = os.path.join(state_path, district)
                files = os.listdir(district_path)
                blocks = set(f.split('_')[0] for f in files if f.endswith('.csv'))

                for block in blocks:
                    macro_path = os.path.join(district_path, f"{block}_macro.csv")
                    micro_path = os.path.join(district_path, f"{block}_micro.csv")
                    if not os.path.exists(macro_path) or not os.path.exists(micro_path):
                        continue
                    try:
                        macro = pd.read_csv(macro_path)
                        micro = pd.read_csv(micro_path)
                        df = pd.merge(macro, micro, on="Village", how="outer")
                        df["Year"] = year
                        df["State"] = state
                        df["District"] = district
                        df["Block"] = block
                        combined.append(df)
                    except Exception as e:
                        print(f"Error processing {district}/{block}: {e}")

    if combined:
        final_df = pd.concat(combined, ignore_index=True)
        final_df.columns = final_df.columns.str.lower().str.replace(" ", "_")
        final_df.to_csv(output_path, index=False)
        print(f"Saved consolidated data to {output_path}")
    else:
        print("No data found to consolidate.")

if __name__ == "__main__":
    consolidate_data()
